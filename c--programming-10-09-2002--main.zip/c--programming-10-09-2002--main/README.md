# c--programming-10-09-2002-

acending order completed

arthimetic operation completed

check_input completed

composite completed

cube completed

factorial completed

perfect_square completed

reverse a digit completed

vowels completed
